# etMINFLUX
Event-triggered MINFLUX controller, written to interact with the Imspector software, in turn controlling a MINFLUX microscope also capable of running confocal imaging. 
