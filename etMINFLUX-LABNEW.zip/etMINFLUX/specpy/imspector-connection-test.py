import specpy as sp
import numpy as np
import inspect

sp.get_application()